package com.ddd_design.orderexample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrderexampleApplication {

    public static void main(String[] args) {
        SpringApplication.run(OrderexampleApplication.class, args);
    }

}
