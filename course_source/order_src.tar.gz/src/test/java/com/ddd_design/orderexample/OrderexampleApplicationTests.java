package com.ddd_design.orderexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderexampleApplicationTests {

    @Test
    void contextLoads() {
    }

}
