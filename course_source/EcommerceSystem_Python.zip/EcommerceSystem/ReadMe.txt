It is convenient to install Anaconda to run this python program.
Please see package-install.txt
To run this python app, in the Anaconda Prompt
python program.py

Then in the Web Browser
http://localhost:9000/v1.0/ui/
