class OrderPlacedEvent:
    def __init__(self, order):
        self.Order = order

