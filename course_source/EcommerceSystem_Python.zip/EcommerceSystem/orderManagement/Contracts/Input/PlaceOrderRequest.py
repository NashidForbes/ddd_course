﻿
class PlaceOrderRequest:
    def __init__(self, order, expectedTotalCost, expectedShippingCost):
        self.Order = order
        self.ExpectedTotalCost = expectedTotalCost
        self.ExpectedShippingCost = expectedShippingCost




