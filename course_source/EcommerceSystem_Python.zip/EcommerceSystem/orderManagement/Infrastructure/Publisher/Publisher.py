﻿from orderManagement.Application.Interfaces.IPublisher import IPublisher


class Publisher(IPublisher):
    def __init__(self):
        return

    def Publish(self, o):
        return




