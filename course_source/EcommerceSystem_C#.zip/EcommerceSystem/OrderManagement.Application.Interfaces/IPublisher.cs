﻿namespace OrderManagement.Application.Interfaces
{
    public interface IPublisher
    {
        void Publish(object o);
    }
}
