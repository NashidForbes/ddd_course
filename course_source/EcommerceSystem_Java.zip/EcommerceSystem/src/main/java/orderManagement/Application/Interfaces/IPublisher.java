package orderManagement.Application.Interfaces;

public interface IPublisher
{
    void Publish(Object o);
}

